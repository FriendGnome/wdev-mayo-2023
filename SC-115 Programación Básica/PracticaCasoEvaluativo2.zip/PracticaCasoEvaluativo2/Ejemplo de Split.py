
#Game of Progra
#Grupo los Erizos   
#Camilo Corrales Sanchez, Eliecer Hernandez Urbina , Julio Andres Perez Piñas 

#En Python, el método split() se utiliza para dividir una
#cadena en partes más pequeñas basadas en un delimitador
#específico. El delimitador es un carácter (o conjunto de caracteres)
#que se utiliza para separar las partes de la cadena.
#Aquí un ejemplo sencillo:

# Cadena de ejemplo
cadena = "Hola,esto,es,un,ejemplo"

# Dividir la cadena utilizando la coma como delimitador
partes = cadena.split(",")

# Imprimir las partes resultantes
print(partes)
