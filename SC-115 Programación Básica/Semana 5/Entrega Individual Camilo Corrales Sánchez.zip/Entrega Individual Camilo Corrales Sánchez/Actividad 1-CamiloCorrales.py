#Actividad Evaluativa 
#Integrante: Corrales Sánchez Camilo,
#Profesor: Salas Sevilla Oscar Francisco

"""
1.Elabore un programa en Python que, solicite al usuario un número entero e imprima en 
pantalla si es un número par o impar.
"""

numero = int(input("Ingrese un número entero:"))

if numero % 2 == 0:
    print("El número es par.")
else:
    print("El número es impar.")